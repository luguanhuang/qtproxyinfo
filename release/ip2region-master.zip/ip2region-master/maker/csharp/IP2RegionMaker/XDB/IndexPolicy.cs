﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IP2RegionMaker.XDB
{
    public enum IndexPolicy
    {
        VectorIndexPolicy = 1,

        BTreeIndexPolicy = 2,
    }
}
