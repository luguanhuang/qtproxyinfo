ip2region的LabVIEW库<br>
使用方法：1. 将该目录下的所有文件复制到你的项目文件夹下；<br>
         2. 导入ip2region.lvlib库文件；<br>
         3. 查看Example.vi，了解使用方法<br>
         <br>
         <br>
注意：该库依赖ni_lib_unicode-2.0.1.5.vip，请使用VIPM安装。
