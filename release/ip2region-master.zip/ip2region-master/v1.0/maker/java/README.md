# db maker java implementation

### 1, How to build ?
```
ant all
```


### 2, How to make ?
```
java -jar dbMaker-{version}.jar -src path of ip.merge.txt -region path of global_region.csv -dst ip2region.db target path
```
