# db maker C# implementation

### 1, 如何编译 ?
```
cd src
dotnet build
```


### 2, 如何生成数据库文件 ?
```
dbMaker -src ./data/ip.merge.txt -region ./data/global_region.csv
```

### 3, 迁移介绍

https://www.coderbusy.com/archives/855.html

